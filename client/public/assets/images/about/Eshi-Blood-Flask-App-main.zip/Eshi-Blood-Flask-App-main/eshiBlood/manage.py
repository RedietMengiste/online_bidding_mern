
from flask_script import Manager
from eshiBlood import app

manager = Manager(app)