from eshiBlood.resources.auth.admin.auth_admin import admin_auth_ns
from eshiBlood.resources.auth.nurse.auth_nurse import nurse_auth_ns
from eshiBlood.resources.auth.donor.auth_donor import donor_auth_ns