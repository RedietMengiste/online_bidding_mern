from eshiBlood import app

# To run as script
if __name__ == "__main__":
    app.run(debug=True)